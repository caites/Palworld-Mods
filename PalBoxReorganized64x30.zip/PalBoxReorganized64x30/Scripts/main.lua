print("PalBoxReorganized loaded\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
	PalGameSetting.PalBoxPageNum = 64
	PalGameSetting.PalBoxSlotNumInPage = 30
end)
