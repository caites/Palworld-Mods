
print("More Technology Points x2 loaded\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
	PalGameSetting.technologyPointPerLevel = 3
	PalGameSetting.TechnologyPoint_UnlockFastTravel = 1
	PalGameSetting.bossTechnologyPointPerTowerBoss = 2
	PalGameSetting.bossTechnologyPointPerNormalBoss = 1
end)
