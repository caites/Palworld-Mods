print("HudFadeout10s loaded\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
	PalGameSetting.hideUITimeWhenNotConflict  = 10

end)
