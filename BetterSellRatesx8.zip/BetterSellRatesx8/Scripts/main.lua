print("BetterSellRates loaded\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
	PalGameSetting.SellItemRate = 0.8
	PalGameSetting.SellPalRate = 0.4

end)
