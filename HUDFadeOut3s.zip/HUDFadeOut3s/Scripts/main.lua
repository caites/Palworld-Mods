print("HudFadeout3s loaded\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
	PalGameSetting.hideUITimeWhenNotConflict  = 3

end)
