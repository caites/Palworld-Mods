--made by caites
print("Better Shields...\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
	--default 25s
	--2 = 2s
	--4 = ~4s
	PalGameSetting.PlayerShield_RecoverStartTime = 40.0
	--default = ~5s	
	--20 = 5s = %20
	--12 = 7.6s = ~13.5%
	--8 = 16.5s = ~6%
	--50 = 2s = 50%
	--100 = 1s = 100%
	--400 = 0.25s = 400%
    PalGameSetting.PlayerShield_RecoverPercentPerSecond = 8.0
     
end)