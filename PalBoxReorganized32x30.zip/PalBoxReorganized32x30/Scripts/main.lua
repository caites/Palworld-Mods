print("PalBoxReorganized loaded\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
	PalGameSetting.PalBoxPageNum = 32
	PalGameSetting.PalBoxSlotNumInPage = 30
end)
