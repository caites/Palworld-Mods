
print("MoreMarkers loaded\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
	PalGameSetting.worldmapUIMaxMarker = 1000
		
end)
