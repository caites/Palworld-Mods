print("BetterSellRates loaded\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
	PalGameSetting.SellItemRate = 0.4
	PalGameSetting.SellPalRate = 0.2

end)
