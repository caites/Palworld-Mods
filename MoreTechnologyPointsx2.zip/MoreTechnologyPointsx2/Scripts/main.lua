
print("More Technology Points x2 loaded\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
	PalGameSetting.technologyPointPerLevel = 12
	PalGameSetting.TechnologyPoint_UnlockFastTravel = 2
	PalGameSetting.bossTechnologyPointPerTowerBoss = 10
	PalGameSetting.bossTechnologyPointPerNormalBoss = 2
end)
