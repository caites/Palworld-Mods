
print("More Technology Points x4 loaded\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
	PalGameSetting.technologyPointPerLevel = 24
	PalGameSetting.TechnologyPoint_UnlockFastTravel = 4
	PalGameSetting.bossTechnologyPointPerTowerBoss = 20
	PalGameSetting.bossTechnologyPointPerNormalBoss = 4
end)
