print("PalBoxReorganized loaded\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
	PalGameSetting.PalBoxPageNum = 40
	PalGameSetting.PalBoxSlotNumInPage = 12
end)
