print("PalBoxReorganized loaded\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
	PalGameSetting.PalBoxPageNum = 10
	PalGameSetting.PalBoxSlotNumInPage = 48
end)
