--made by caites
print("Dead bodies despawn faster loaded\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
	PalGameSetting.DeadBodyDestroySecond = 0.2
		
end)