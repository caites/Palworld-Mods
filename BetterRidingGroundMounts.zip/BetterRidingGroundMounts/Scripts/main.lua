--made by caites
print("Better Riding loaded...\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)

	--default 45 degrees
    PalGameSetting.WalkableFloorAngleForRide = 70.00   

	
end)