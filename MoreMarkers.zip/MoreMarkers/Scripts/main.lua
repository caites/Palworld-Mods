
print("MoreMarkers loaded\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
	PalGameSetting.worldmapUIMaxMarker = 200
		
end)
