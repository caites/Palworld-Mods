-- Configurable
-- Building Experience, default is 3
BuildExp = 3

-- Crafting Experience, default is 2
CraftExp = 0

-- Experience on resources pickup, default is 1
PickupItemOnLevelExp = 1


print("Configurable Exp Gain loaded\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
	PalGameSetting.PickupItemOnLevelExp = PickupItemOnLevelExp
	PalGameSetting.BuildExp = BuildExp
	PalGameSetting.CraftExp = CraftExp
end)
