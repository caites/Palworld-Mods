print("PalBoxReorganized loaded\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
	PalGameSetting.PalBoxPageNum = 20
	PalGameSetting.PalBoxSlotNumInPage = 24
end)
