print("No damaged equipment penalties 50% loaded\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
	PalGameSetting.BreakedWeaponDamageRate = 1.0
	PalGameSetting.BreakedArmorDefenseRate = 1.0

end)
