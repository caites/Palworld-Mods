
print("LessMapShroud loaded\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
	PalGameSetting.worldmapUIMaskClearSize = 30
		
end)
