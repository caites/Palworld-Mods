print("MaxLevelIncreased loaded\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(var)
	var.CharacterMaxLevel = 79
	var.GuildCharacterMaxLevel = 79
	var.OtomoLevelSyncAddMaxLevel = 79
end)
