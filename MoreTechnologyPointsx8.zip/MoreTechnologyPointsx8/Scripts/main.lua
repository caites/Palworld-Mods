
print("More Technology Points x8 loaded\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
	PalGameSetting.technologyPointPerLevel = 48
	PalGameSetting.TechnologyPoint_UnlockFastTravel = 8
	PalGameSetting.bossTechnologyPointPerTowerBoss = 40
	PalGameSetting.bossTechnologyPointPerNormalBoss = 8
end)
