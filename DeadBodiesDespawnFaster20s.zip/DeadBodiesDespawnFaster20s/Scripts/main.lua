--made by caites
print("Dead bodies despawn faster loaded\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
	PalGameSetting.DeadBodyDestroySecond = 20.0
		
end)