--made by caites

print("No More Burned Bases loaded\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
	PalGameSetting.MapObjectEffectTriggerAccumulate_Burn = 200.00
		
end)