print("MaxLevelIncreased loaded\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(var)
	var.CharacterMaxLevel = 70
	var.GuildCharacterMaxLevel = 70
	var.OtomoLevelSyncAddMaxLevel = 70
end)
