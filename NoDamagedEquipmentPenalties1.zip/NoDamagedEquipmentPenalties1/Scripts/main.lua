print("No damaged equipment penalties 50% loaded\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
	PalGameSetting.BreakedWeaponDamageRate = 0
	PalGameSetting.BreakedArmorDefenseRate = 0

end)
