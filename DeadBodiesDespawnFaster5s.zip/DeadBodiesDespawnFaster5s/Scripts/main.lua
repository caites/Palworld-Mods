--made by caites
print("Dead bodies despawn faster loaded\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
	PalGameSetting.DeadBodyDestroySecond = 5.0
		
end)