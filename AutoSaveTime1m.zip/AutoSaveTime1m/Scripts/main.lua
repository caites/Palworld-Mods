
print("AutoSave Time loaded\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
	PalGameSetting.AutoSaveSpan = 60
		
end)
