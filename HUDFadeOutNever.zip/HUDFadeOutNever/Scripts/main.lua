print("HudFadeoutNever loaded\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
	PalGameSetting.hideUITimeWhenNotConflict  = 999999

end)
