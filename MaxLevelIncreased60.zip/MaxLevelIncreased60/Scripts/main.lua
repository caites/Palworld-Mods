print("MaxLevelIncreased loaded\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(var)
	var.CharacterMaxLevel = 60
	var.GuildCharacterMaxLevel = 60
	var.OtomoLevelSyncAddMaxLevel = 60
end)
