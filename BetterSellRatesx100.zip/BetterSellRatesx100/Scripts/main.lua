print("BetterSellRates x100 loaded\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
	PalGameSetting.SellItemRate = 10.0
	PalGameSetting.SellPalRate = 5.0

end)
