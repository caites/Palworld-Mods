--made by caites
print("Setting Pal Spawn Distance from bases values...\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
    PalGameSetting.SpawnerDisableDistanceCM_FromBaseCamp = 10000.0
     
end)