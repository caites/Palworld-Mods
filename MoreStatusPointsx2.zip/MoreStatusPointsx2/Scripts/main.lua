
print("More Status Points x2 loaded\n")

NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
	PalGameSetting.StatusPointPerLevel = 2
end)
